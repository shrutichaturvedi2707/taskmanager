Task Tracker Web Application

The Task Tracker web application is a simple task management tool that allows users to add, edit, and delete tasks. 

Features:
Task Management: You can add new tasks, including a title, description, and due date. Tasks can be edited or deleted.
Dropdown Menu: A user-friendly dropdown menu for easy navigation between Home, Features, and Contact sections.
Responsive Design: The application is designed to work well on both desktop and mobile devices.

Usage:
Upon opening the application, you will see the "Task Tracker" header with a dropdown menu on the right side.
To add a new task, fill out the task title, description, and due date in the input fields and click "Add Task."
Your task will appear in the task list below.
You can edit or delete tasks using the provided buttons.
Use the dropdown menu to navigate between Home, Features, and Contact sections.

